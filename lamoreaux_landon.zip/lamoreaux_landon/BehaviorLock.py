
# The interface for the lock behavior.
class BehaviorLock:
    def do_algorithm(self, lock, pass_boat, in_boat, out_boat):
        pass
