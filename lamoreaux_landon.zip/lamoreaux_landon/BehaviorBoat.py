
# The interface for the boat behavior.
class BehaviorBoat:
    def do_algorithm(self, pass_boat, units, unit, flow, in_boat, out_boat):
        pass
